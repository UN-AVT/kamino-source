International Data Base (IDB)
December 2020 Release

These data files correspond to the data available in the U.S. Census Bureau's API. Each file is pipe "|" delimited, and the header row is demarcated with "#" at the start of the row. For additional technical specifications, including variable definitions, please visit https://www.census.gov/data/developers/data-sets/international-database.html

For more information about the International Data Base, including release notes and detailed methodology, please visit https://www.census.gov/programs-surveys/international-programs/about/idb.html

Please email any questions to pop.ipc.des.web@census.gov

U.S. Census Bureau
Population Division
International Programs
Washington, DC 20233
census.gov/internationalprograms